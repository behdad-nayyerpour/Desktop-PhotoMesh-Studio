"""Offline reconstruction capabilities and conservative hardware policies.

Engine flags come from the actual executable's help, not a version guess.
Native probes and processing are separate child processes. No network calls.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import subprocess
from pathlib import Path

PINNED_VERSION = "4.2.1"
_PROBES = {}
_GPU = None
_MODEL_STAMPS = {}


def fingerprint(exe):
    try:
        stat = os.stat(exe)
        return (os.path.abspath(exe), stat.st_size, stat.st_mtime_ns)
    except OSError:
        return (str(exe), 0, 0)


def child_env(exe):
    """COLMAP's Qt/DLL paths must never contaminate PySide6 in the host."""
    env = dict(os.environ)
    base = Path(exe).resolve().parent
    root = base.parent if base.name.lower() == "bin" else base
    paths = [str(base), str(root / "lib")]
    # ONNX in the pinned modern engine uses CUDA 12; dense COLMAP uses CUDA 13.
    # Keep the additional DLLs private to native children, after engine-owned
    # directories, without changing PySide/Python or the legacy engine's lookup.
    neural = Path(__file__).resolve().parent / 'resources' / 'neural-cuda12'
    if neural.is_dir() and bundle_manifest(exe).get('version') == PINNED_VERSION:
        paths.append(str(neural))
    env["PATH"] = os.pathsep.join(paths + [env.get("PATH", "")])
    env.pop("QT_PLUGIN_PATH", None)
    env.pop("QT_QPA_PLATFORM_PLUGIN_PATH", None)
    for plugins in (root / "plugins", root / "lib" / "plugins"):
        if plugins.is_dir():
            env["QT_PLUGIN_PATH"] = str(plugins)
            break
    env["QT_QPA_PLATFORM"] = "offscreen"
    # Explicit local model paths are supplied below; no URL defaults are used.
    return env


def run_help(exe, command="help"):
    key = (fingerprint(exe), command)
    if key not in _PROBES:
        try:
            result = subprocess.run([exe, command, "-h"] if command != "help" else [exe, "help"],
                                    capture_output=True, text=True, errors="replace", timeout=20,
                                    env=child_env(exe),
                                    creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            text = result.stdout + result.stderr
            _PROBES[key] = text if result.returncode == 0 else ""
        except (OSError, subprocess.TimeoutExpired):
            _PROBES[key] = ""
    return _PROBES[key]


def commands(exe):
    return set(re.findall(r"^\s+([a-z][a-z0-9_]+)\s*(?:\n|:)", run_help(exe), re.MULTILINE))


def has_global(exe):
    return "global_mapper" in run_help(exe)


def hardware():
    global _GPU
    if _GPU is None:
        from .colmap import python_exe, task_env
        try:
            result = subprocess.run([python_exe(), "-m", "photomesh.engine_probe"],
                                    capture_output=True, text=True, timeout=8, env=task_env(),
                                    creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            data = json.loads(result.stdout) if result.returncode == 0 else {}
            _GPU = data if isinstance(data, dict) else {}
        except (OSError, ValueError, subprocess.TimeoutExpired):
            _GPU = {}
    return _GPU


def bundle_manifest(exe):
    root = Path(exe).resolve().parent
    if root.name.lower() == "bin":
        root = root.parent
    path = root / "photomesh-engine.json"
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
        return value if isinstance(value, dict) else {}
    except (OSError, ValueError):
        return {}


def gpu_device(exe, requested=True):
    if not requested or os.environ.get("PHOTOMESH_FORCE_NO_GPU"):
        return None
    banner = run_help(exe)
    if not banner or "without cuda" in banner.lower() or not re.search(r"\bCUDA\b", banner):
        return None
    manifest = bundle_manifest(exe)
    if manifest.get("cuda") is False:
        return None
    info = hardware()
    minimum = int(manifest.get("minimum_driver", 0))
    if int(info.get("driver", 0)) < minimum:
        return None
    devices = [d for d in info.get("devices", [])
               if int(d.get("cc", 0)) >= int(manifest.get("minimum_cc", 0))
               and int(d.get("memory", 0)) >= 1024**3]
    return max(devices, key=lambda d: int(d["memory"]), default=None)


def group_capability(exe, command):
    from .colmap import colmap_options
    return any(key in colmap_options(exe, command) for key in ("FeatureExtraction.type", "FeatureMatching.type"))


# ALIKED allocates dense feature maps before selecting keypoints. The keypoint
# limit alone cannot bound its multi-GB full-resolution ONNX intermediates.
ALIKED_MAX_IMAGE_SIZE = 2048


def extraction_size(requested, settings):
    """Bound neural image memory consistently in every alignment pipeline."""
    if settings.get("feature_method") == "ALIKED + LightGlue":
        return min(int(requested), ALIKED_MAX_IMAGE_SIZE)
    return int(requested)


def matching_arguments(exe, command, settings, extraction=False):
    """Select compatible feature types and local weights; reject silent substitutions."""
    from .colmap import colmap_options, opt
    supported = colmap_options(exe, command)
    method = settings.get("feature_method", "SIFT")
    requested = method != "SIFT"
    device = gpu_device(exe, settings.get("use_gpu", False)) if requested or bundle_manifest(exe) or group_capability(exe, command) else None
    # Legacy SIFT builders retain their tested behavior. Bundled modern engines use the probe.
    use_gpu = bool(device) if bundle_manifest(exe) or requested or group_capability(exe, command) else bool(settings.get("use_gpu", False))
    group = "FeatureExtraction" if extraction else "FeatureMatching"
    args = opt(exe, command, [group + ".use_gpu",
                            "SiftExtraction.use_gpu" if extraction else "SiftMatching.use_gpu"], int(use_gpu))
    if device and group + ".gpu_index" in supported:
        args += ["--" + group + ".gpu_index", str(device["index"])]
    if method == "SIFT":
        if group + ".type" in supported:
            args += ["--" + group + ".type", "SIFT" if extraction else "SIFT_BRUTEFORCE"]
        return args
    limit = settings.get("key_point_limit", 0)
    if limit <= 0 or limit > 4096:
        raise ValueError("Neural matching requires an explicit feature limit from 1 to 4096")
    if group + ".num_threads" in supported:
        args += ["--" + group + ".num_threads", "1" if extraction or use_gpu else "2"]
    if method not in ("SIFT + LightGlue", "ALIKED + LightGlue"):
        raise ValueError("Unknown feature method: " + str(method))
    key = group + ".type"
    if key not in supported:
        raise ValueError("This engine has no neural-feature support. Select SIFT or install the complete modern engine.")
    aliked = method.startswith("ALIKED")
    kind = ("ALIKED_N16ROT" if aliked else "SIFT") if extraction else (
        "ALIKED_LIGHTGLUE" if aliked else "SIFT_LIGHTGLUE")
    args += ["--" + key, kind]
    model_name = "aliked-n16rot.onnx" if extraction and aliked else (
        ("aliked-lightglue.onnx" if aliked else "sift-lightglue.onnx") if not extraction else None)
    if model_name:
        path = verified_model(exe, model_name)
        option = ("AlikedExtraction.n16rot_model_path" if extraction else
                  ("AlikedMatching.lightglue_model_path" if aliked else "SiftMatching.lightglue_model_path"))
        if option not in supported:
            raise ValueError("Required offline-model option is unsupported: " + option)
        args += ["--" + option, path]
    if extraction and aliked and settings.get("key_point_limit", 0) > 0:
        if "AlikedExtraction.max_num_features" not in supported:
            raise ValueError("Engine cannot enforce the requested ALIKED feature limit")
        args += ["--AlikedExtraction.max_num_features", str(settings["key_point_limit"])]
    return args


def verified_model(exe, name):
    manifest = bundle_manifest(exe)
    models = manifest.get("models", {})
    root = Path(exe).resolve().parent
    root = root.parent if root.name.lower() == "bin" else root
    path = root / "models" / name
    expected = models.get(name)
    if not isinstance(expected, str) or len(expected) != 64 or not path.is_file():
        raise ValueError("Offline model missing: " + name + ". Reinstall the complete Setup; processing never downloads models.")
    stamp = (str(path), path.stat().st_size, path.stat().st_mtime_ns, path.stat().st_ctime_ns)
    if _MODEL_STAMPS.get(stamp) != expected:
        with path.open("rb") as handle:
            digest = hashlib.file_digest(handle, "sha256").hexdigest()
        if digest != expected:
            raise ValueError("Offline model checksum mismatch: " + name)
        _MODEL_STAMPS[stamp] = expected
    return str(path)


def global_arguments(exe, settings, database, images, output, coarse=False):
    """Use maintained global mapping; Ceres CPU is the safe solver default.

    A CUDA-enabled executable does not prove that Ceres was built with cuDSS.
    Enable its GPU solvers only in an explicitly certified bundle.
    """
    from .colmap import colmap_options
    opts = colmap_options(exe, "global_mapper")
    if not opts or not has_global(exe):
        return None
    result = ["global_mapper", "--database_path", database, "--image_path", images, "--output_path", output]
    if "GlobalMapper.skip_retriangulation" in opts:
        result += ["--GlobalMapper.skip_retriangulation", str(int(coarse))]
    if "GlobalMapper.random_seed" in opts:
        result += ["--GlobalMapper.random_seed", "0"]
    # Do not automatically activate experimental backends or unsupported camera models.
    device = gpu_device(exe, settings.get("use_gpu", False))
    gpu = bool(device) and bundle_manifest(exe).get("ceres_cuda") is True
    for key in ("GlobalMapper.gp_use_gpu", "GlobalMapper.ba_ceres_use_gpu"):
        if key in opts:
            result += ["--" + key, str(int(gpu))]
    if gpu:
        for key in ("GlobalMapper.gp_gpu_index", "GlobalMapper.ba_gpu_index"):
            if key in opts:
                result += ["--"+key,str(device["index"])]
    return result


def synchronize_database_frames(connection):
    """Rebuild trivial single-photo frames after calibration groups change.

    The application aligns independent photographs, not synchronized multi-camera
    rigs. Reject a real rig before mutation rather than corrupting its graph.
    """
    tables = {r[0] for r in connection.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    if not {"rigs", "rig_sensors", "frames", "frame_data"} <= tables:
        return
    if connection.execute("SELECT COUNT(*) FROM rig_sensors").fetchone()[0]:
        raise ValueError("Multi-camera rigs require a dedicated rig workflow; calibration grouping was cancelled.")
    connection.execute("DELETE FROM frame_data")
    connection.execute("DELETE FROM frames")
    connection.execute("DELETE FROM rigs")
    ids = [r[0] for r in connection.execute("SELECT DISTINCT camera_id FROM images")]
    connection.executemany("INSERT INTO rigs(rig_id,ref_sensor_id,ref_sensor_type) VALUES(?,?,0)", [(cid,cid) for cid in ids])
    if "pose_priors" in tables:
        columns={row[1] for row in connection.execute("PRAGMA table_info(pose_priors)")}
        if {"corr_data_id","corr_sensor_id","corr_sensor_type"}<=columns:
            connection.execute("UPDATE pose_priors SET corr_sensor_id=(SELECT camera_id FROM images WHERE image_id=pose_priors.corr_data_id) WHERE corr_sensor_type=0 AND EXISTS(SELECT 1 FROM images WHERE image_id=pose_priors.corr_data_id)")
    rows = list(connection.execute("SELECT image_id,camera_id FROM images"))
    connection.executemany("INSERT INTO frames(frame_id,rig_id) VALUES(?,?)", rows)
    connection.executemany("INSERT INTO frame_data(frame_id,data_id,sensor_id,sensor_type) VALUES(?,?,?,0)",
                           [(iid,iid,cid) for iid,cid in rows])


def validate_model(folder):
    """Reject a numerically invalid generation before publishing camera poses."""
    import numpy as np
    from .colmap_io import read_model
    model = read_model(folder)
    if len(model.images) < 2 or not len(model.points):
        raise ValueError("Reconstruction has insufficient registered cameras or tie points")
    for cam in model.cameras.values():
        if cam.model not in (0,1,2,3,4,5,6) or not np.isfinite(cam.params).all() or min(cam.K()[:2]) <= 0:
            raise ValueError("Reconstruction contains unsupported or invalid calibration")
    for im in model.images.values():
        R = im.R()
        if im.camera_id not in model.cameras or not np.isfinite(im.xys).all():
            raise ValueError("Reconstruction contains an invalid image/calibration link")
        if not np.isfinite(im.tvec).all() or not np.isfinite(R).all() or not np.allclose(R.T @ R, np.eye(3), atol=1e-6):
            raise ValueError("Reconstruction contains an invalid camera pose")
    if not np.isfinite(model.points.xyz).all():
        raise ValueError("Reconstruction contains non-finite 3D points")
    P=model.points
    if len(P.track_start)!=len(P)+1 or P.track_start[0]!=0 or np.any(np.diff(P.track_start)<0) or P.track_start[-1]!=len(P.track_img) or len(P.track_idx)!=len(P.track_img):
        raise ValueError("Reconstruction contains malformed observation tracks")
    image_ids=np.array(sorted(model.images),dtype=np.uint32)
    positions=np.searchsorted(image_ids,P.track_img)
    if np.any(positions>=len(image_ids)) or not np.array_equal(image_ids[np.minimum(positions,len(image_ids)-1)],P.track_img):
        raise ValueError("Reconstruction observation references a missing image")
    counts=np.array([len(model.images[int(iid)].xys) for iid in image_ids],dtype=np.int64)
    if np.any(P.track_idx>=counts[positions]):
        raise ValueError("Reconstruction observation lies outside its image feature array")
    return model


def sibling_engine(exe, name):
    root = Path(exe).resolve().parent
    root = root.parent if root.name.lower() == "bin" else root
    for candidate in (root.parent / name / "bin" / "colmap.exe",
                      root.parent / name / "bin" / "colmap",
                      root.parent / name / "colmap"):
        if candidate.is_file():
            return str(candidate)
    return None


_SELECTION = {}


def selection_known(exe):
    return fingerprint(exe) in _SELECTION


def select_bundled(exe):
    key=fingerprint(exe)
    if key not in _SELECTION:
        _SELECTION[key]=_select_bundled(exe)
    return _SELECTION[key]


def _select_bundled(exe):
    if not bundle_manifest(exe):
        return exe
    if gpu_device(exe):
        return exe
    legacy=sibling_engine(exe,"colmap-legacy")
    if legacy and gpu_device(legacy):
        return legacy
    cpu = sibling_engine(exe, "colmap-cpu")
    if cpu and run_help(cpu):
        return cpu
    if run_help(exe):
        return exe  # CPU feature flags remain forced off for an incompatible GPU.
    return None


def dense_executable(exe):
    from .colmap import has_cuda
    if gpu_device(exe):
        return exe
    if not bundle_manifest(exe):
        return exe if has_cuda(exe) else None
    for name in ("colmap", "colmap-legacy"):
        other = sibling_engine(exe, name)
        if other and gpu_device(other):
            return other
    return None


_PREFLIGHT = {}


def execution_settings(exe, settings, workdir, log=print):
    """Small real extraction/matching probe, cached for this engine/model/device.

    A GPU failure retries only the probe on CPU. Survey databases are never
    mixed, reduced in quality, or partially reused across feature types.
    """
    import tempfile
    from PIL import Image
    import numpy as np
    from .colmap import opt
    s = dict(settings)
    s["engine_version"]=bundle_manifest(exe).get("version","legacy/custom")
    s["engine_executable"]=exe
    method = s.get("feature_method", "SIFT")
    device = gpu_device(exe, s.get("use_gpu", False))
    s["use_gpu"] = bool(device)
    key = (fingerprint(exe), method, json.dumps(device, sort_keys=True))
    # Recheck model identity even when the native compatibility result is cached.
    if method != "SIFT":
        matching_arguments(exe, "feature_extractor", s, True)
        matching_arguments(exe, "matches_importer", s, False)
    if key in _PREFLIGHT:
        s["use_gpu"] = _PREFLIGHT[key]
        return s
    with tempfile.TemporaryDirectory(prefix="engine-probe-", dir=workdir) as folder:
        photos = Path(folder) / "photos"
        photos.mkdir()
        rng = np.random.default_rng(811)
        image = rng.integers(0, 256, (96, 128, 3), dtype=np.uint8)
        for name in ("a.png", "b.png"):
            Image.fromarray(image).save(photos / name)
        pairs = Path(folder) / "pairs.txt"
        pairs.write_text("a.png b.png\n", encoding="utf-8")
        for attempt in range(2 if device else 1):
            db = str(Path(folder) / ("probe" + str(attempt) + ".db"))
            probe_s = dict(s, key_point_limit=128)
            extract = ["feature_extractor", "--database_path", db, "--image_path", str(photos)]
            extract += matching_arguments(exe, "feature_extractor", probe_s, True)
            extract += opt(exe, "feature_extractor", ["SiftExtraction.max_num_features"], 128)
            match = ["matches_importer", "--database_path", db, "--match_list_path", str(pairs), "--match_type", "pairs"]
            match += matching_arguments(exe, "matches_importer", probe_s, False)
            failure = None
            for command in (extract, match):
                try:
                    result = subprocess.run([exe, *command], capture_output=True, text=True,
                                            errors="replace", timeout=90, env=child_env(exe),
                                            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
                    if result.returncode:
                        failure = (result.stderr + result.stdout)[-2500:]
                        break
                except (OSError, subprocess.TimeoutExpired) as error:
                    failure = str(error)
                    break
            if failure is None:
                _PREFLIGHT[key] = s["use_gpu"]
                log(f"Engine check passed: {method}; {'GPU ' + device['name'] if s['use_gpu'] else 'CPU'}.")
                return s
            if attempt == 0 and device:
                s["use_gpu"] = False
                log("Native GPU compatibility probe failed; retrying the same feature method on CPU.")
            else:
                raise ValueError(f"Engine compatibility check failed for {method}. "
                                 "No survey files were changed. Select SIFT or reinstall the full Setup.\n" + failure)
    return s


def gps_frame_available(cameras, crs="", existing_alignment=False, *, respect_legacy_flags=True):
    """GPS references must define a 2-D footprint, not just have three rows."""
    import numpy as np
    from .georef import CRS, utm_forward, geographic_zone, valid_gps
    if existing_alignment:
        return False, "The existing project frame is preserved. Use Optimize Cameras to apply GPS to this project."
    if crs and CRS.parse(crs).kind == "local":
        return False, "Choose a geographic/UTM project CRS before using camera GPS."
    values=[]
    for camera in cameras:
        if not camera.enabled or (respect_legacy_flags and not camera.use_reference):
            continue
        xyz=valid_gps((camera.lon,camera.lat,camera.alt))
        if xyz is not None: values.append(xyz)
    if len(values)<3:
        return False, "At least three cameras with valid longitude, latitude and altitude are required."
    values=np.asarray(values,float)
    try:
        zone,south=geographic_zone(values)
    except ValueError as error:
        return False,str(error)
    east,north=utm_forward(values[:,1],values[:,0],zone,south)
    ground=np.column_stack([east,north])
    singular=np.linalg.svd(ground-ground.mean(0),compute_uv=False)
    if len(singular)<2 or singular[1]<max(1e-3,singular[0]*1e-4):
        return False, "GPS positions are collinear or have insufficient footprint spread."
    return True, "Apply a similarity from valid GPS positions. GPS measurement accuracy limits the result."


def feature_executable(exe,settings):
    """Preserve working legacy GPU SIFT on older drivers; route neural methods
    to the modern offline engine without sending new flags to the old binary.
    """
    if settings.get("feature_method","SIFT")=="SIFT":
        return exe
    from .colmap import colmap_options
    if "FeatureExtraction.type" in colmap_options(exe,"feature_extractor"):
        return exe
    for name in ("colmap","colmap-cpu"):
        candidate=sibling_engine(exe,name)
        if not candidate: continue
        if name=="colmap" and not gpu_device(candidate):
            continue
        if "FeatureExtraction.type" in colmap_options(candidate,"feature_extractor"):
            return candidate
    raise ValueError("No compatible offline neural engine is installed. Reinstall the complete Setup or select SIFT.")


def bind_steps(exe,steps):
    """Bind dynamic native commands to the engine used to construct their flags."""
    from .colmap import Cmd,PYTHON,GLOMAP
    result=[]
    def bind_callback(callback):
        def run():
            return bind_steps(exe,callback() or [])
        return run
    for label,action,weight in steps:
        if callable(action):
            action=bind_callback(action)
        elif isinstance(action,list) and action and action[0] not in (PYTHON,GLOMAP):
            if not hasattr(action,"meter"):
                action=Cmd(action)
            action.executable=exe
            if hasattr(action,"fallback") and action.fallback:
                action.fallback=bind_callback(action.fallback)
        result.append((label,action,weight))
    return result
