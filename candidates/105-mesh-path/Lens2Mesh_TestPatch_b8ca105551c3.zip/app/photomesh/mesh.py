"""Build Mesh from the dense cloud: screened Poisson (Open3D) with density
trimming, or COLMAP's Delaunay mesher; then cleanup and decimation.

Face count presets follow the usual photogrammetry rule of thumb
(High = points/5, Medium = points/15, Low = points/45 faces).
Large clouds are voxel-downsampled first so Poisson stays within RAM.
"""
from __future__ import annotations

import os
import math

import numpy as np

FACE_FACTOR = {"High": 5, "Medium": 15, "Low": 45}
# Poisson density trimming quantile per interpolation mode
TRIM_QUANTILE = {"Disabled": 0.08, "Enabled": 0.02, "Extrapolated": 0.0}


def target_faces(n_points, preset="Medium", custom=None):
    if preset == "Custom" and custom:
        return int(custom)
    return max(1000, int(n_points / FACE_FACTOR.get(preset, 15)))


def poisson_depth(n_points, target=None):
    """Octree depth: enough resolution for the point count, capped for RAM.

    With a face target, go one level coarser for every 4x surplus: Poisson
    produces about 2 faces per point at the full depth and each level less
    divides that by 4, so the result stays >= ~3x the target and decimation
    (single-threaded, the slowest step) has far less to do."""
    d = int(np.clip(round(np.log(max(n_points, 1)) / np.log(4)) + 1, 8, 12))
    if target:
        surplus = 2.0 * n_points / (3.0 * max(target, 1))
        if surplus > 1:
            d -= int(np.floor(np.log(surplus) / np.log(4)))
    return int(np.clip(d, 8, 12))


def _o3d():
    import open3d as o3d
    o3d.utility.set_verbosity_level(o3d.utility.VerbosityLevel.Error)
    return o3d


def _unicode_ply(path):
    # Open3D's Windows file API converts through the legacy ANSI code page.
    return os.name == 'nt' and not os.fspath(path).isascii()


def _read_ply_geometry(path, triangles=False):
    """Use existing Python PLY I/O without reducing coordinate precision."""
    from .plyio import read_fast
    from .plycodec import PlyDocument
    data = read_fast(path)
    if data is None:
        document = PlyDocument.read(path)
        vertex = document['vertex'].data
        faces = None
        if triangles:
            records = document['face'].data
            key = 'vertex_indices' if 'vertex_indices' in records.dtype.names else records.dtype.names[0]
            if any(len(row) != 3 for row in records[key]):
                raise ValueError('Meshing input must contain triangular faces')
            faces = np.asarray(list(records[key]), dtype=np.int32).reshape(-1, 3)
    else:
        vertex, faces = data['vertex'], data['face']
    o3d = _o3d()
    xyz = np.column_stack([vertex[name] for name in ('x','y','z')]).astype(np.float64)
    if triangles:
        if faces is None:
            raise ValueError('Meshing input has no triangular faces')
        result = o3d.geometry.TriangleMesh(o3d.utility.Vector3dVector(xyz), o3d.utility.Vector3iVector(faces))
    else:
        result = o3d.geometry.PointCloud(o3d.utility.Vector3dVector(xyz))
    for fields, attribute, scale in ((('nx','ny','nz'), 'vertex_normals' if triangles else 'normals', 1.),
                                     (('red','green','blue'), 'vertex_colors' if triangles else 'colors', 255.)):
        if all(name in vertex.dtype.names for name in fields):
            values = np.column_stack([vertex[name] for name in fields]).astype(np.float64) / scale
            setattr(result, attribute, o3d.utility.Vector3dVector(values))
    return result


def _write_ply_mesh(path, mesh):
    from .plycodec import PlyDocument, PlyElement
    fields = [('x','f8'),('y','f8'),('z','f8')]
    if mesh.has_vertex_normals():
        fields += [('nx','f8'),('ny','f8'),('nz','f8')]
    if mesh.has_vertex_colors():
        fields += [('red','u1'),('green','u1'),('blue','u1')]
    vertex = np.empty(len(mesh.vertices), dtype=fields)
    for names, values in ((('x','y','z'), np.asarray(mesh.vertices)),
                           (('nx','ny','nz'), np.asarray(mesh.vertex_normals))):
        if all(name in vertex.dtype.names for name in names):
            for index, name in enumerate(names):
                vertex[name] = values[:, index]
    if mesh.has_vertex_colors():
        colors = np.floor(np.clip(np.asarray(mesh.vertex_colors), 0., 1.) * 255. + .5).astype(np.uint8)
        for index, name in enumerate(('red','green','blue')):
            vertex[name] = colors[:, index]
    faces = np.empty(len(mesh.triangles), dtype=[('vertex_indices','i4',(3,))])
    faces['vertex_indices'] = np.asarray(mesh.triangles)
    PlyDocument([PlyElement.describe(vertex,'vertex'), PlyElement.describe(faces,'face')], text=False).write(path)
    return True


def load_point_cloud(path, max_points=12_000_000, voxel=None, log=print):
    o3d = _o3d()
    from .workflow import point_count, vertex_blocks, bounds_from_ply, require_points
    from .memguard import require_available_bytes
    n = point_count(path)
    if not n:
        raise ValueError("Point cloud is empty")
    max_points = max(1000, int(max_points))
    # Normal-sized clouds retain the optimized native loader.
    if n <= max_points and n * 100 < require_available_bytes() * .6:
        pcd = _read_ply_geometry(path) if _unicode_ply(path) else o3d.io.read_point_cloud(path)
        if voxel:
            pcd = pcd.voxel_down_sample(float(voxel))
    else:
        lo, hi = bounds_from_ply(path)
        area = max(float(np.sort(hi-lo)[-2:].prod()), 1e-12)
        v = float(voxel or max(math.sqrt(area / max_points), 1e-9))
        pcd = o3d.geometry.PointCloud()
        for records in vertex_blocks(path):
            xyz = np.column_stack([records["x"], records["y"], records["z"]])
            require_points(xyz,"Point cloud")
            block = o3d.geometry.PointCloud(o3d.utility.Vector3dVector(xyz))
            if all(k in records.dtype.names for k in ("red", "green", "blue")):
                block.colors = o3d.utility.Vector3dVector(np.column_stack(
                    [records["red"], records["green"], records["blue"]]) / 255.)
            if all(k in records.dtype.names for k in ("nx", "ny", "nz")):
                block.normals = o3d.utility.Vector3dVector(np.column_stack(
                    [records["nx"], records["ny"], records["nz"]]))
            pcd += block.voxel_down_sample(v)
            if len(pcd.points) > 2 * max_points:
                pcd = pcd.voxel_down_sample(v)
                if not voxel and len(pcd.points) > max_points:
                    v *= max(1.1, math.sqrt(len(pcd.points) / max_points))
                    pcd = pcd.voxel_down_sample(v)
        pcd = pcd.voxel_down_sample(v)
    if voxel and len(pcd.points) > max_points:
        raise ValueError(f"Manual voxel retains {len(pcd.points):,} points, above the {max_points:,} limit. "
                         "Increase voxel size or the point limit; the previous mesh was kept.")
    while not voxel and len(pcd.points) > max_points:
        extent = pcd.get_max_bound() - pcd.get_min_bound()
        v = max(math.sqrt(max(float(np.sort(extent)[-2:].prod()), 1e-12) / max_points), 1e-9)
        before = len(pcd.points)
        pcd = pcd.voxel_down_sample(v)
        if len(pcd.points) >= before:
            pcd = pcd.uniform_down_sample(max(2, math.ceil(before/max_points)))
    require_points(np.asarray(pcd.points),"Point cloud")
    if len(pcd.points) < 4:
        raise ValueError("Too few points after downsampling")
    log(f"Meshing points: {n:,} -> {len(pcd.points):,}; hard limit {max_points:,}")
    return pcd, n


def ensure_normals(pcd, cam_center=None):
    o3d = _o3d()
    if not pcd.has_normals():
        pcd.estimate_normals(o3d.geometry.KDTreeSearchParamKNN(16))
        if cam_center is not None:
            pcd.orient_normals_towards_camera_location(np.asarray(cam_center, float))
    return pcd


def poisson(pcd, depth=None, trim_quantile=0.02, log=print, target=None):
    o3d = _o3d()
    depth = depth or poisson_depth(len(pcd.points), target)
    mesh, dens = o3d.geometry.TriangleMesh.create_from_point_cloud_poisson(
        pcd, depth=depth, scale=1.1, linear_fit=False, n_threads=-1)
    dens = np.asarray(dens)
    nv = len(mesh.vertices)
    if trim_quantile > 0:
        mesh.remove_vertices_by_mask(dens < np.quantile(dens, trim_quantile))
    log(f"Poisson depth {depth}: {nv:,} vertices, {len(mesh.triangles):,} faces after density trim")
    return mesh


def crop_to_cloud(mesh, pcd, max_dist):
    """Remove faces whose centroid is farther than max_dist from the cloud
    (Poisson surfaces bridging gaps / extrapolated borders)."""
    from scipy.spatial import cKDTree
    tree = cKDTree(np.asarray(pcd.points))
    V = np.asarray(mesh.vertices); F = np.asarray(mesh.triangles)
    cen = V[F].mean(1)
    d, _ = tree.query(cen, k=1, workers=-1)
    mesh.remove_triangles_by_mask(d > max_dist)
    mesh.remove_unreferenced_vertices()
    return int((d > max_dist).sum())


def remove_long_edges(mesh, factor=8.0):
    V = np.asarray(mesh.vertices); F = np.asarray(mesh.triangles)
    if not len(F):
        return 0
    e = np.stack([np.linalg.norm(V[F[:, i]] - V[F[:, (i + 1) % 3]], axis=1) for i in range(3)], 1).max(1)
    bad = e > factor * np.median(e)
    mesh.remove_triangles_by_mask(bad); mesh.remove_unreferenced_vertices()
    return int(bad.sum())


def remove_small_components(mesh, min_fraction=0.01, min_faces=200):
    tri, counts, _ = mesh.cluster_connected_triangles()
    tri = np.asarray(tri); counts = np.asarray(counts)
    if not len(counts):
        return 0
    thr = max(min_faces, min_fraction * counts.max())
    bad = counts[tri] < thr
    mesh.remove_triangles_by_mask(bad); mesh.remove_unreferenced_vertices()
    return int(bad.sum())


def decimate(mesh, target):
    if len(mesh.triangles) > target:
        mesh = mesh.simplify_quadric_decimation(int(target))
        mesh.remove_unreferenced_vertices()
    return mesh


def clean(mesh, log=print, long_edge_factor=8.0, min_component=0.01, min_component_faces=200):
    mesh.remove_duplicated_vertices(); mesh.remove_degenerate_triangles()
    mesh.remove_duplicated_triangles(); mesh.remove_non_manifold_edges()
    a = remove_long_edges(mesh, long_edge_factor) if long_edge_factor else 0
    b = remove_small_components(mesh, min_component, min_component_faces) if (min_component or min_component_faces) else 0
    log(f"Cleanup: removed {a:,} long-edge faces, {b:,} faces in small components")
    return mesh


def commit_mesh(tmp, out):
    """Replace out with the freshly written mesh tmp, but only when tmp is a
    complete PLY with faces; otherwise tmp is removed and out is left as it was."""
    from .plyio import read_header
    why = ""
    try:
        with open(tmp, "rb") as fh:
            h = read_header(fh)
        if h is None:
            raise ValueError("not a PLY file")
        head, end, elems = h
        counts = {name: n for name, n, _ in elems}
        nv, nf = counts.get("vertex", 0), counts.get("face", 0)
        body = os.path.getsize(tmp) - len(head)
        if end:                               # binary: the data must be at least this long
            need = 0
            for _name, n, props in elems:
                for pr in props:
                    if pr is None:
                        continue
                    need += n * np.dtype(pr[2] if pr[0] == "list" else pr[1]).itemsize
            if body < need:
                why = f"truncated ({body:,} of at least {need:,} data bytes)"; body = 0
    except Exception as e:  # noqa: BLE001
        nv = nf = body = 0; why = str(e)
    if not (nv and nf and body):
        try:
            os.remove(tmp)
        except OSError:
            pass
        raise RuntimeError(f"The new mesh has no faces or is incomplete{': ' + why if why else ''} - the previous model was kept")
    for k in range(20):
        try:
            os.replace(tmp, out); return nv, nf
        except PermissionError:            # Windows: model briefly open by AV/indexer/viewer
            if k == 19:
                raise
            import time; time.sleep(0.25)


def build_mesh(cfg, log=print):
    """cfg: source ('Point cloud'|'Depth maps'), cloud, out, face_count, custom_faces,
    interpolation, voxel, max_points, delaunay_ply (for Depth maps), cam_center."""
    o3d = _o3d()
    import time
    t0 = time.perf_counter()
    if cfg["source"] == "Point cloud":
        pcd, n_in = load_point_cloud(cfg["cloud"], cfg.get("max_points", 12_000_000),
                                     cfg.get("voxel"), log)
        ensure_normals(pcd, cfg.get("cam_center"))
        tgt0 = target_faces(n_in, cfg.get("face_count", "Medium"), cfg.get("custom_faces"))
        mesh = poisson(pcd, cfg.get("depth"), TRIM_QUANTILE.get(cfg.get("interpolation", "Enabled"), 0.02), log,
                       target=tgt0)
        if cfg.get("interpolation", "Enabled") != "Extrapolated":
            sp = np.asarray(pcd.compute_nearest_neighbor_distance())
            n = crop_to_cloud(mesh, pcd, 8 * float(np.median(sp)))
            log(f"Removed {n:,} faces farther than 8x point spacing from the cloud (gaps)")
    else:
        mesh = (_read_ply_geometry(cfg['delaunay_ply'], triangles=True) if _unicode_ply(cfg['delaunay_ply'])
                else o3d.io.read_triangle_mesh(cfg["delaunay_ply"]))
        n_in = cfg.get("n_points") or len(mesh.vertices) * 2
    mesh = clean(mesh, log, cfg.get("long_edge_factor", 8.0), cfg.get("min_component", 0.01), cfg.get("min_component_faces", 200))
    tgt = target_faces(n_in, cfg.get("face_count", "Medium"), cfg.get("custom_faces"))
    nf = len(mesh.triangles)
    mesh = decimate(mesh, tgt)
    log(f"Decimation: {nf:,} -> {len(mesh.triangles):,} faces (target {tgt:,})")
    mesh = clean(mesh, log, 0, cfg.get("min_component", 0.01))
    mesh.compute_vertex_normals()
    if not len(mesh.triangles):
        raise RuntimeError("Meshing produced no faces - the previous model was kept")
    tmp = cfg.get("tmp") or cfg["out"]
    written = (_write_ply_mesh(tmp, mesh) if _unicode_ply(tmp) else
               o3d.io.write_triangle_mesh(tmp, mesh, write_ascii=False, compressed=False,
                                         write_vertex_normals=True, write_vertex_colors=mesh.has_vertex_colors()))
    if not written:
        raise RuntimeError(f"Could not write {tmp}")
    if tmp != cfg["out"]:
        commit_mesh(tmp, cfg["out"])
    log(f"Mesh: {len(mesh.vertices):,} vertices, {len(mesh.triangles):,} faces "
        f"({time.perf_counter() - t0:.1f} s) -> {cfg['out']}")
    return {"faces": len(mesh.triangles), "vertices": len(mesh.vertices)}
