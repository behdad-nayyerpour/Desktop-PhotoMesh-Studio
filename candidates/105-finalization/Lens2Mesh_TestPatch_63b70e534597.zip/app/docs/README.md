# Documentation

## Using Lens2Mesh

- [Installation and requirements](installation.md)
- [Installing a newer version](../UPDATING.md)
- [User guide](user-guide.md)
- [1.0.5 candidate additions and limitations](candidate-105.md)
- [Troubleshooting](troubleshooting.md)
- [Changelog](../CHANGES.md)

## Development

- [Run from source and test](development/README.md)
- [1.0.4 numerical review and installer validation](development/release-review-104.md)
- [1.0.3 baseline review](development/release-review-103.md)
- [Release quality checklist](development/release-quality.md)
- [Architecture and performance](development/architecture.md)
- [Project notes and third-party components](development/project-notes.md)
- [Build and publish an installer](../packaging/RELEASE.md)

[Back to the main page](../README.md)
